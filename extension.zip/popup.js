const API_URL = 'https://c096da6f702a.ngrok.app'; // Your current ngrok URL

document.addEventListener('DOMContentLoaded', () => {
  const button = document.getElementById('analyze');
  const status = document.getElementById('status');

  // Check for active jobs for this URL
  chrome.tabs.query({ active: true, currentWindow: true }, ([tab]) => {
    if (chrome.storage?.local) {
      chrome.storage.local.get(['activeJobs'], (data) => {
        const activeJobs = data.activeJobs || {};
        const urlJobs = activeJobs[tab.url] || [];
        
        if (urlJobs.length > 0) {
          // Show status of most recent job
          const latestJob = urlJobs[urlJobs.length - 1];
          showStatus(latestJob.jobId);
        }
      });
    }
  });

  button.addEventListener('click', async () => {
    button.disabled = true;
    status.textContent = 'Capturing content...';

    try {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });

      // Inject content script if not already injected
      await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        files: ['content.js']
      });

      // Wait for script to initialize
      await new Promise(resolve => setTimeout(resolve, 200));
      
      status.textContent = 'Capturing content...';
      
      // Capture page content
      const response = await chrome.tabs.sendMessage(tab.id, { 
        type: 'CAPTURE_FULL_PAGE' 
      });

      if (response.error) {
        throw new Error(response.error);
      }

      if (!response?.content) {
        throw new Error('No content captured');
      }

      status.textContent = 'Starting analysis...';

      // Queue the analysis
      const analysisResponse = await fetch(`${API_URL}/api/analyze/queue`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          url: tab.url,
          title: tab.title,
          html: response.content,
          screenshot_data: response.screenshot
        })
      });

      const data = await analysisResponse.json();
      
      if (!analysisResponse.ok) {
        throw new Error(data.error || 'Failed to start analysis');
      }

      // Add job to storage
      if (chrome.storage?.local) {
        chrome.storage.local.get(['activeJobs'], (result) => {
          const activeJobs = result.activeJobs || {};
          const urlJobs = activeJobs[tab.url] || [];
          
          urlJobs.push({
            jobId: data.jobId,
            timestamp: Date.now()
          });

          chrome.storage.local.set({ 
            activeJobs: {
              ...activeJobs,
              [tab.url]: urlJobs
            }
          });
        });
      }

      showStatus(data.jobId);

    } catch (error) {
      console.error('Analysis failed:', error);
      status.textContent = `Error: ${error.message}`;
      status.classList.add('error');
    } finally {
      button.disabled = false;
    }
  });
});

function showStatus(jobId) {
  const status = document.getElementById('status');
  status.innerHTML = `
    <div class="status-links">
      <a href="${API_URL}/report/${jobId}" target="_blank" class="status-link">
        View Analysis
      </a>
    </div>
  `;
} 